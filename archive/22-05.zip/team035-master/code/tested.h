#ifndef test_H_   /* Include guard */
#define test_H_

void tested_implementation(int hiddenStates, int differentObservables, int T, double* transitionMatrix, double* emissionMatrix, double* stateProb, int* observations);  

#endif // test_H_
